import cv2
import sys

print("Testing webcam...")

# Try different indices
for i in range(0, 4):
    try:
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"✅ Webcam found at index {i}")
            ret, frame = cap.read()
            if ret:
                print(f"   Resolution: {frame.shape[1]}x{frame.shape[0]}")
            cap.release()
            
            # Test if we can actually use it
            cap = cv2.VideoCapture(i)
            if cap.isOpened():
                print(f"   Can open successfully: Yes")
                cap.release()
            else:
                print(f"   Can open successfully: No")
                
        else:
            print(f"❌ No webcam at index {i}")
    except Exception as e:
        print(f"❌ Error with index {i}: {e}")

print("\nTry using these commands with yolo_detect.py:")
print("python yolo_detect.py --model my_model.pt --source 0 --resolution 1280x720")
print("python yolo_detect.py --model my_model.pt --source 1 --resolution 1280x720")
