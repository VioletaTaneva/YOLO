import tkinter as tk
from tkinter import filedialog, messagebox
import os
import threading
import cv2
from ultralytics import YOLO

class YOLOFrontend:
    def __init__(self, root):
        self.root = root
        self.root.title("Simple YOLO Project")
        self.root.geometry("700x600")
        self.root.configure(bg="#2c3e50")
        self.root.resizable(False, False)

        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        # ===== Main Container =====
        main_frame = tk.Frame(root, bg="#2c3e50", padx=20, pady=20)
        main_frame.pack(fill="both", expand=True)

        # ===== Title =====
        title_frame = tk.Frame(main_frame, bg="#2c3e50")
        title_frame.pack(pady=(30, 20))

        tk.Label(
            title_frame, 
            text="SIMPLE YOLO PROJECT",
            font=("Arial", 28, "bold"),
            bg="#2c3e50", 
            fg="#ecf0f1"
        ).pack()

        tk.Label(
            title_frame,
            text="Detects computer mouses, telephones, faces, eggs, peaches and lemons!",
            font=("Arial", 12),
            bg="#2c3e50",
            fg="#bdc3c7",
            wraplength=500,
            justify="center"
        ).pack(pady=(10, 0))

        # ===== Buttons Frame =====
        button_frame = tk.Frame(main_frame, bg="#2c3e50")
        button_frame.pack(pady=30)

        # Create rounded buttons
        self.create_rounded_button(button_frame, "START CAMERA", self.start_camera, "#e74c3c", 0)
        self.create_rounded_button(button_frame, "UPLOAD PICTURE", self.upload_picture, "#3498db", 1)
        self.create_rounded_button(button_frame, "UPLOAD VIDEO", self.upload_video, "#2ecc71", 2)

        # ===== Status =====
        status_frame = tk.Frame(main_frame, bg="#34495e", relief="flat", bd=0)
        status_frame.pack(fill="x", pady=(30, 10), ipady=10)

        self.status_label = tk.Label(
            status_frame,
            text="Ready - Click a button to start detection",
            font=("Arial", 11),
            bg="#34495e",
            fg="#ecf0f1",
            pady=8
        )
        self.status_label.pack()

        # Load YOLO model
        try:
            self.model = YOLO("my_model.pt")
            self.update_status("Model loaded successfully", "#27ae60")
        except Exception as e:
            messagebox.showerror("Model Error", f"Could not load YOLO model: {e}")
            self.model = None
            self.update_status("Model failed to load", "#e74c3c")

        self.stop_flag = False

    def create_rounded_button(self, parent, text, command, color, row):
        """Create large rounded buttons with modern design"""
        btn_frame = tk.Frame(parent, bg="#2c3e50")
        btn_frame.grid(row=row, column=0, pady=15)

        btn = tk.Button(
            btn_frame,
            text=text,
            command=command,
            font=("Arial", 16, "bold"),
            width=20,
            height=2,
            bg=color,
            fg="#ffffff",
            activebackground=color,
            activeforeground="#ffffff",
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=20
        )
        btn.pack()

        # Hover effect
        def on_enter(e):
            btn.config(bg=self.lighten_color(color))
        def on_leave(e):
            btn.config(bg=color)
        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)

    def lighten_color(self, color):
        """Lighten the button color on hover"""
        if color == "#e74c3c": return "#ff6b6b"
        elif color == "#3498db": return "#5dade2"
        elif color == "#2ecc71": return "#58d68d"
        return color

    def update_status(self, message, color="#27ae60"):
        self.status_label.config(text=message, fg=color)

    def on_close(self):
        """Handle closing of the app."""
        self.stop_flag = True
        cv2.destroyAllWindows()
        self.root.destroy()

    # ================= CAMERA =================
    def start_camera(self):
        threading.Thread(target=self.run_camera_detection, daemon=True).start()

    def run_camera_detection(self):
        if not self.model:
            self.update_status("Model not loaded", "#e74c3c")
            return

        self.update_status("Opening camera...", "#3498db")
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

        if not cap.isOpened():
            self.update_status("Camera not found", "#e74c3c")
            messagebox.showerror("Camera Error", "Could not open camera.")
            return

        window_name = "YOLO Detection - Press Q to exit"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

        while not self.stop_flag:
            ret, frame = cap.read()
            if not ret or frame is None:
                break

            results = self.model(frame)
            annotated_frame = results[0].plot()

            cv2.imshow(window_name, annotated_frame)

            key = cv2.waitKey(1) & 0xFF
            # Exit if 'q' pressed OR OpenCV window closed
            if key == ord('q') or cv2.getWindowProperty(window_name, cv2.WND_PROP_VISIBLE) < 1:
                self.stop_flag = True
                break

        cap.release()
        cv2.destroyAllWindows()
        self.update_status("Camera closed", "#27ae60")

    # ================= UPLOAD IMAGE =================
    def upload_picture(self):
        file_path = filedialog.askopenfilename(
            title="Select an image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp *.gif")]
        )
        if file_path:
            threading.Thread(target=self.run_image_detection, args=(file_path,), daemon=True).start()

    def run_image_detection(self, file_path):
        if not self.model:
            self.update_status("Model not loaded", "#e74c3c")
            return

        self.update_status(f"Processing image: {os.path.basename(file_path)}", "#3498db")
        try:
            img = cv2.imread(file_path)
            if img is None:
                raise ValueError("Image could not be read")

            results = self.model(img)
            annotated_img = results[0].plot()

            cv2.imshow(f"YOLO Image Detection - {os.path.basename(file_path)}", annotated_img)
            cv2.waitKey(0)
            cv2.destroyAllWindows()

            self.update_status("Image processed successfully", "#27ae60")
        except Exception as e:
            self.update_status("Error processing image", "#e74c3c")
            messagebox.showerror("Error", f"Detection failed: {e}")

    # ================= UPLOAD VIDEO =================
    def upload_video(self):
        file_path = filedialog.askopenfilename(
            title="Select a video",
            filetypes=[("Video files", "*.mp4 *.avi *.mov *.mkv *.wmv")]
        )
        if file_path:
            threading.Thread(target=self.run_video_detection, args=(file_path,), daemon=True).start()

    def run_video_detection(self, file_path):
        if not self.model:
            self.update_status("Model not loaded", "#e74c3c")
            return

        self.update_status(f"Processing video: {os.path.basename(file_path)}", "#3498db")
        cap = cv2.VideoCapture(file_path)
        if not cap.isOpened():
            self.update_status("Video not found", "#e74c3c")
            messagebox.showerror("Video Error", "Could not open video file.")
            return

        window_name = f"YOLO Video Detection - {os.path.basename(file_path)}"
        cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

        while not self.stop_flag:
            ret, frame = cap.read()
            if not ret:
                break

            results = self.model(frame)
            annotated_frame = results[0].plot()

            cv2.imshow(window_name, annotated_frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q') or cv2.getWindowProperty(window_name, cv2.WND_PROP_VISIBLE) < 1:
                self.stop_flag = True
                break

        cap.release()
        cv2.destroyAllWindows()
        self.update_status("Video processed successfully", "#27ae60")


if __name__ == "__main__":
    root = tk.Tk()
    app = YOLOFrontend(root)
    root.mainloop()

 